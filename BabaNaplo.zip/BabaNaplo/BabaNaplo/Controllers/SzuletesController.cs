﻿using BabaNaplo.Models;
using BabaNaplo.Models.DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System.Security.Cryptography.Xml;

namespace BabaNaplo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SzuletesController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            var context = new BabanaploContext();
            try
            {
                return Ok(context.Szuletes.ToList());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }

        [HttpGet("GetFull")]
        public IActionResult GetFull()
        {
            var context = new BabanaploContext();
            try
            {
                var result = context.Szuletes.Include(x => x.Kedvenceks).Select(f => new {f.Nev, f.Kedvenceks} );
                return Ok(result);
            }
            catch (Exception ex)

            { return BadRequest(ex.Message); }
        }
        [HttpGet("GetDTO")]

        public async Task<IActionResult> GetDTO()
        {
            var context = new BabanaploContext();
            try
            {
                return Ok(await context.Szuletes.Select(f => new SzuletesDTO() { Id = f.BabaId, Nev = f.Nev, Hely = f.Hely, Idopont = f.Idopont }).ToListAsync());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }
        [HttpPost]

        public IActionResult Post(Szuletes szuletes)
        {
            var context = new BabanaploContext();
            try
            {
                context.Add(szuletes);
                context.SaveChanges();
                return Ok(context.Szuletes);
            }
            catch (Exception ex)

            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]

        public IActionResult Put(Szuletes szuletes)
        {
            var context = new BabanaploContext();
            try
            {
                context.Update(szuletes);
                context.SaveChanges();
                return Ok(context.Szuletes);
            }
            catch (Exception ex)

            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]

        public IActionResult Delete(int id)
        {
            var context = new BabanaploContext();
            try
            {
                Szuletes szuletes = new Szuletes();
                szuletes.BabaId = id;
                context.Remove(szuletes);
                context.SaveChanges();
                return StatusCode(StatusCodes.Status200OK, "Sikeres törlés.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, ex.Message);
            }
        }
    }
}

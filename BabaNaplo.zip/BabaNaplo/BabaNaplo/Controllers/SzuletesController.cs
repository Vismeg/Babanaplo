﻿using BabaNaplo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BabaNaplo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SzuletesController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            var context = new BabanaploContext();
            try
            {
                return Ok(context.Szuletes.ToList());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }

        [HttpGet("GetFull")]
        public IActionResult GetFull()
        {
            var context=new BabanaploContext();
            try
            {
                return Ok(context.Szuletes.Include(f => f.Esemenyeks).Include(f=>f.Kedvenceks).Include(f=>f.Novekedess).ToList());
            }
            catch (Exception ex)

            { return BadRequest(ex.Message); }  
        }
        [HttpPost]

        public IActionResult Post(Szuletes szuletes)
        {
            var context = new BabanaploContext();
            try
            {
                context.Add(szuletes);
                context.SaveChanges();
                return Ok(context.Szuletes);    
            }
            catch (Exception ex)

            {
                return BadRequest(ex.Message);
            }
        }
    }
}

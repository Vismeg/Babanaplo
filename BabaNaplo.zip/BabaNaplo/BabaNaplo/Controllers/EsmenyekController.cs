﻿using BabaNaplo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BabaNaplo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EsmenyekController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            var context=new BabanaploContext();
            try
            {
                return Ok(context.Esemenyeks.ToList());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);  
                
            }
        }
        [HttpPost]

        public IActionResult Post(Esemenyek esemenyek)
        {
            var context = new BabanaploContext();
            try
            {
                context.Add(esemenyek);
                context.SaveChanges();
                return Ok(context.Esemenyeks);
            }
            catch (Exception ex)

            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]

        public IActionResult Put(Esemenyek esemenyek)
        {
            var context = new BabanaploContext();
            try
            {
                context.Update(esemenyek);
                context.SaveChanges();
                return Ok(context.Esemenyeks);
            }
            catch (Exception ex)

            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]

        public IActionResult Delete(int id)
        {
            var context = new BabanaploContext();
            try
            {
                Esemenyek esemenyek = new Esemenyek();
                esemenyek.Id = id;
                context.Remove(esemenyek);
                context.SaveChanges();
                return StatusCode(StatusCodes.Status200OK, "Sikeres törlés.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, ex.Message);
            }

        }
    }
}

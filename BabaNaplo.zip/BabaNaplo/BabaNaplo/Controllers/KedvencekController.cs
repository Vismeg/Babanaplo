﻿using BabaNaplo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BabaNaplo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class KedvencekController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            var context = new BabanaploContext();
            try
            {
                return Ok(context.Kedvenceks.ToList());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }
    }
}

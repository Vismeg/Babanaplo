﻿using BabaNaplo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BabaNaplo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class KedvencekController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            var context = new BabanaploContext();
            try
            {
                return Ok(context.Kedvenceks.ToList());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);

            }
        }
        [HttpPost]

        public IActionResult Post(Kedvencek kedvencek)
        {
            var context = new BabanaploContext();
            try
            {
                context.Add(kedvencek);
                context.SaveChanges();
                return Ok(context.Kedvenceks);
            }
            catch (Exception ex)

            {
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]

        public IActionResult Put(Kedvencek kedvencek)
        {
            var context = new BabanaploContext();
            try
            {
                context.Update(kedvencek);
                context.SaveChanges();
                return Ok(context.Kedvenceks);
            }
            catch (Exception ex)

            {
                return BadRequest(ex.Message);
            }
        }
        [HttpDelete("{id}")]

        public IActionResult Delete(int id)
        {
            var context = new BabanaploContext();
            try
            {
                Kedvencek kedvencek = new Kedvencek();
                kedvencek.Id = id;
                context.Remove(kedvencek);
                context.SaveChanges();
                return StatusCode(StatusCodes.Status200OK, "Sikeres törlés.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, ex.Message);
            }

        }
    }
}

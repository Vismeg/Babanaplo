﻿using System;
using System.Collections.Generic;

namespace BabaNaplo.Models;

public partial class Novekedes
{
    public int Id { get; set; }

    public int BabaId { get; set; }

    public float? Suly { get; set; }

    public float? Magassag { get; set; }

    public byte[]? Kep { get; set; }

    public virtual Szuletes Baba { get; set; } = null!;
}

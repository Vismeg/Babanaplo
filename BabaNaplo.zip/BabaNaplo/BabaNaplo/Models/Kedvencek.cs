﻿using System;
using System.Collections.Generic;

namespace BabaNaplo.Models;

public partial class Kedvencek
{
    public int Id { get; set; }

    public int Babaid { get; set; }

    public string? Ital { get; set; }

    public string? Jatek { get; set; }

    public string? Mese { get; set; }

    public string? Mondoka { get; set; }

    public string? Etel { get; set; }

    public virtual Szuletes Baba { get; set; } = null!;
}

﻿namespace BabaNaplo.Models
{
    public class Megnevezes
    {
        public int Id { get; set; } 
        public string megnevezes { get; set; }
    }
}

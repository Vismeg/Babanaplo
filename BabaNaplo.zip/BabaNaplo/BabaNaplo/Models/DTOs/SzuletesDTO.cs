﻿namespace BabaNaplo.Models.DTOs
{
    public class SzuletesDTO
    {
        public int Id { get; set; }  
        public string Nev { get; set; }
        public DateTime Idopont { get; set;}
        public string Hely {  get; set; }


    }
}

﻿namespace BabaNaplo.Models
{
    public class Szuletes
    {
        public int Id { get; set; }
        public string Nev { get; set; }
        public DateOnly Date { get; set;}
        public int Ora {  get; set;}
        public int Perc { get; set;}
        public string Hely { get; set;}
        public int Suly {  get; set;}
        public int Hossz { get; set;}   
        public string Hajszin { get; set;}
        public string Szemszin { get; set;}
        public string Vercsoport { get; set;}
        public string Csillagjegy { get; set;}
        public string Szuletestort { get; set;}
        public byte[] Babafoto { get; set;}

    }
}

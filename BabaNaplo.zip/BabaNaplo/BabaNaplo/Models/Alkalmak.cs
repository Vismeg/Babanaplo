﻿namespace BabaNaplo.Models
{
    public class Alkalmak
    {
        public int Id { get; set; }
        public string BabaId { get; set; }
        public string Megnevezes { get; set;}
        
        public byte[] Kep { get; set; }    
        public string Tortenet { get;}

        public DateOnly Datum {  get; set; }

        public DateTime FelviteliDatum { get; set; }

    }
}
